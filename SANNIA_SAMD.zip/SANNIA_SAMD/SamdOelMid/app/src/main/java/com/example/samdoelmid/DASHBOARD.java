package com.example.samdoelmid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DASHBOARD extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button btn1_signup=findViewById(R.id.btn_on);
        Button btn2_signup=findViewById(R.id.btn_off);
        Button btn3_signup=findViewById(R.id.btn_on1);
        Button btn4_signup=findViewById(R.id.btn_off1);
        Button btn11_signup=findViewById(R.id.btn_on11);
        Button btn22_signup=findViewById(R.id.btn_off22);
        Button btn33_signup=findViewById(R.id.btn_on33);
        Button btn44_signup=findViewById(R.id.btn_off44);

        btn1_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU ADD ONE WATCH ITEM",Toast.LENGTH_SHORT).show();

            }
        });

        btn3_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"MUSIC PLAYED",Toast.LENGTH_SHORT).show();

            }
        });


        btn2_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU DELETE ONE WATCH ITEM",Toast.LENGTH_SHORT).show();

            }
        });


        btn4_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"MUSIC STOP",Toast.LENGTH_SHORT).show();

            }
        });

        btn11_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU ADD ONE DRESS ITEM",Toast.LENGTH_SHORT).show();

            }
        });

        btn33_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU ADD ONE FOOD ITEM",Toast.LENGTH_SHORT).show();

            }
        });


        btn22_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU DELETE ONE DRESS ITEM",Toast.LENGTH_SHORT).show();

            }
        });


        btn44_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"YOU DELETE ONE FOOD ITEM",Toast.LENGTH_SHORT).show();

            }
        });
    }
}