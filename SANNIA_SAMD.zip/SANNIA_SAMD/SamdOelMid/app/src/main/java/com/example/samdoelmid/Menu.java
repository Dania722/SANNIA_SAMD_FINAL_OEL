package com.example.samdoelmid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Button btn1_signup=findViewById(R.id.btn_camera);
        Button btn2_signup=findViewById(R.id.btn_rooms);
        Button btn4_signup=findViewById(R.id.btn_car);

        btn1_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menu.this, ORDER_MANAGEMENT.class));
            }
        });

        btn2_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menu.this, DASHBOARD.class));
            }
        });

        btn4_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menu.this, CHECKOUT.class));
            }
        });

    }
}