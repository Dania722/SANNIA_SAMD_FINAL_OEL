package com.example.samdoelmid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CHECKOUT extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        Button btn1_signup=findViewById(R.id.btn_on);
        Button btn2_signup=findViewById(R.id.btn_off);
        Button btn3_signup=findViewById(R.id.btn_on1);
        Button btn4_signup=findViewById(R.id.btn_off1);

        btn1_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"I HOPE YOU ENJOY",Toast.LENGTH_SHORT).show();

            }
        });

        btn3_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"THANKYOU GOOD CUSTOMER",Toast.LENGTH_SHORT).show();

            }
        });


        btn2_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"SORRY WE WORKING ON IT",Toast.LENGTH_SHORT).show();

            }
        });


        btn4_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"I NOTICED YOUR COMPLAIN",Toast.LENGTH_SHORT).show();

            }
        });
    }
}